﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppFPA
{
    public class Beitrag
    {
        private int id;
        private string betreff;
        private string beitragstext;
        ObservableCollection<Benutzer> likes;
        public int Count { get { return likes.Count; } }

        public Beitrag(int id, string betreff, string beitragstext)
        {
            likes = new ObservableCollection<Benutzer>();
            this.id = id;
            this.betreff = betreff;
            this.beitragstext = beitragstext;
        }

        public bool Liken(Benutzer benutzer)
        {
            if (!Likes.Contains(benutzer))
            {
                Likes.Add(benutzer);
                return true;
            }
            else
            {
                return false;
            }
        }

        public int Id { get => id; set => id = value; }
        public string Betreff { get => betreff; set => betreff = value; }
        public string Beitragstext { get => beitragstext; set => beitragstext = value; }
        public ObservableCollection<Benutzer> Likes { get => likes; set => likes = value; }
        public override string ToString()
        {
            return betreff;
        }
    }
}
