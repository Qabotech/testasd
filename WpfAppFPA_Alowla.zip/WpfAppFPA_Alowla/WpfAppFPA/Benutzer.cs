﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppFPA
{
    public class Benutzer
    {
        private ObservableCollection<Beitrag> beitraege;

        private int id;
        private string nickname;
        private string vorname;
        private string nachname;
        private DateTime geburtsdatum;

        public Benutzer(int id, string nickname, string vorname, string nachname, DateTime geburtsdatum)
        {
            beitraege = new ObservableCollection<Beitrag>();

            this.id = id;
            this.nickname = nickname;
            this.vorname = vorname;
            this.nachname = nachname;
            this.geburtsdatum = geburtsdatum;
        }

        public ObservableCollection<Beitrag> Beitraege { get => beitraege; set => beitraege = value; }

        public int Id { get => id; set => id = value; }
        public string Nickname { get => nickname; set => nickname = value; }
        public string Vorname { get => vorname; set => vorname = value; }
        public string Nachname { get => nachname; set => nachname = value; }
        public DateTime Geburtsdatum { get => geburtsdatum; set => geburtsdatum = value; }

        public override string ToString()
        {
            return nickname;
        }
    }
}
