﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppFPA
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Verwaltung vw;
        public MainWindow()
        {
            InitializeComponent();
            vw = (DataContext as Verwaltung);
            vw.OnFehler += Ereignis;
        }

        private void Ereignis(int i)
        {
            MessageBox.Show("Schon "+i+" Likes");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            vw.ButtonLike(datagridBeitraege.SelectedItem as Beitrag, comboBoxBenutzer.SelectedItem as Benutzer);

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            vw.ButtonBeitrag(comboBoxBenutzer.SelectedItem as Benutzer, textBoxBetreff.Text, textBoxBeitrag.Text);
        }
    }
}
