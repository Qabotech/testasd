﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.ComponentModel;

namespace WpfAppFPA
{
    public class Verwaltung : INotifyPropertyChanged
    {
        private ObservableCollection<Benutzer> benutzerList;
        private ObservableCollection<Beitrag> beitragList;
        public delegate void Fehler(int i);
        public Fehler OnFehler;
        OleDbConnection con;

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, e);
        }

        public Verwaltung()
        {
            benutzerList = new ObservableCollection<Benutzer>();
            BeitragList = new ObservableCollection<Beitrag>();
            con = new OleDbConnection(Properties.Settings.Default.DBPath);
            DatenLesen();
        }

        private void DatenLesen()
        {

            con.Open();
            OleDbCommand com = con.CreateCommand();
            com.CommandText = "Benutzer";
            com.CommandType = CommandType.TableDirect;
            OleDbDataReader oleDbDataReader = com.ExecuteReader();
            while (oleDbDataReader.Read())
            {
                Benutzer benutzer = new Benutzer(oleDbDataReader.GetInt32(0), oleDbDataReader.GetString(1), oleDbDataReader.GetString(2), oleDbDataReader.GetString(3), oleDbDataReader.GetDateTime(4));
                benutzerList.Add(benutzer);
            }
            oleDbDataReader.Close();

            com.CommandText = "Beitrag";
            com.CommandType = CommandType.TableDirect;
            oleDbDataReader = com.ExecuteReader();
            while (oleDbDataReader.Read())
            {
                Beitrag beitrag = new Beitrag(oleDbDataReader.GetInt32(0), oleDbDataReader.GetString(2), oleDbDataReader.GetString(3));
                int id = oleDbDataReader.GetInt32(1);
                (benutzerList.Single(b => b.Id == id)).Beitraege.Add(beitrag);
                BeitragList.Add(beitrag);
            }
            oleDbDataReader.Close();

            com.CommandText = "Likes";
            com.CommandType = CommandType.TableDirect;
            oleDbDataReader = com.ExecuteReader();
            while (oleDbDataReader.Read())
            {
                int idN = oleDbDataReader.GetInt32(1);
                int idB = oleDbDataReader.GetInt32(0);

                Beitrag b = BeitragList.Single(bt => bt.Id == idB);
                b.Likes.Add(benutzerList.Single(bn => bn.Id == idN));


            }
            oleDbDataReader.Close();
            con.Close();
        }   
        public void ButtonLike(Beitrag beitrag, Benutzer benutzer)
        {
            if (beitrag.Liken(benutzer))
            {

     
                con.Open();
                OleDbCommand com = con.CreateCommand();
                com.CommandText = "INSERT INTO Likes (BeitragID, BenutzerID) VALUES (?, ?);";
                com.Parameters.AddWithValue("@BeitragID", beitrag.Id);
                com.Parameters.AddWithValue("@BenutzerID", benutzer.Id);
                com.ExecuteNonQuery();
                con.Close();
                if (OnFehler != null)
                    OnFehler(beitrag.Count);
            }

        }
        public void ButtonBeitrag(Benutzer benutzer, string betreff, string text)
        {
            con.Open();
            OleDbCommand com = con.CreateCommand();
            com.CommandText = "INSERT INTO Beitrag (BenutzerID, Betreff, Beitragstext) VALUES (?, ?, ?);";

            com.Parameters.AddWithValue("@BenutzerID", benutzer.Id);
            com.Parameters.AddWithValue("@Betreff", betreff);
            com.Parameters.AddWithValue("@BenutzerID", text);
            com.ExecuteNonQuery();
            OleDbCommand cmdIdentity = new OleDbCommand("SELECT @@IDENTITY", con);
            int id = (int)cmdIdentity.ExecuteScalar();
            con.Close();
            BeitragList.Add(new Beitrag(id, betreff, text));
            OnPropertyChanged(new PropertyChangedEventArgs("BeitragList"));
            
        }

        public ObservableCollection<Benutzer> BenutzerList { get => benutzerList; set => benutzerList = value; }
        public ObservableCollection<Beitrag> BeitragList { get => beitragList; set => beitragList = value; }
    }
}
